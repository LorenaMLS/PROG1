#include <stdio.h>
#include <stdlib.h>
#include "liblista_ordenada.h"

lista_t *lista_cria()
{

    lista_t *l;

    if (!(l = malloc(sizeof(lista_t))))
        return NULL;

    l->ini = NULL;

    return l;
}

/*
 * Destroi a Lista e a aponta para NULL
 */
void lista_destroi(lista_t **l)
{

    nodo_t *aux;
    while ((*l)->ini != NULL)
    {
        aux = (*l)->ini;
        (*l)->ini = aux->prox;
        free(aux);
    }
    free(*l);
    *l = NULL;
}

/*
 * Adiciona um elemento em ordem de acordo com o valor elemento->chave na Lista.
 * Retorna 1 em caso de sucesso e 0 caso contrario.
 */
int lista_insere_ordenado(lista_t *l, elemento_t *elemento)
{
    nodo_t *novo, *aux;

    if (!(novo = malloc(sizeof(nodo_t))))
        return 0;

    novo->elemento = elemento;

    if (l->ini == NULL)
    {
        l->ini = novo;
        novo->prox = NULL;
        return 1;
    }
    /*se for o pŕimeiro elemento a ser acresentado na lista*/
    else if (novo->elemento->chave < (l->ini)->elemento->chave)
    {
        novo->prox = l->ini;
        l->ini = novo;
        return 1;
    }

    else
    {
        aux = l->ini;
        while (aux->prox != NULL && novo->elemento->chave > aux->prox->elemento->chave)
            aux = aux->prox;

        novo->prox = aux->prox;
        aux->prox = novo;
        return 1;
    }
    return 0;
}

/*
 * Retira o elemento da Lista e a mantem em ordem.
 * Retorna 1 em caso de sucesso e 0 caso elemento nao esteja na Lista.
 */
int lista_remove_ordenado(lista_t *l, elemento_t *elemento)
{
    nodo_t *aux, *aux2;

    if (l->ini == NULL)
        return 0;

    else if (l->ini->elemento->chave == elemento->chave)
    {
        aux = l->ini;
        l->ini = aux->prox;
        free(aux);
        return 1;
    }
    else
    {
        aux = l->ini;
        while (aux->prox != NULL && aux->prox->elemento->chave > elemento->chave)
        {
            aux = aux->prox;

            if (aux->prox == NULL)
                return 0;

            aux = aux->prox;
            aux2 = aux->prox;
            aux->prox = aux2->prox;
            free(aux2);
            return 1;
        }
        return 0;
    }
}
